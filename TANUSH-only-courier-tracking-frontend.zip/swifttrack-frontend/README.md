# TANUSH – Front-end Website

A responsive HTML, CSS and JavaScript front-end for a Courier & Parcel Tracking Management System.

## Run in VS Code
1. Extract the ZIP.
2. Open this folder in Visual Studio Code.
3. Open `index.html` in your browser, or use the VS Code Live Server extension and click **Go Live**.

## Pages
Home, About Us, Services, Book Parcel, Track Parcel, Customers and Dashboard.

## Important
This package is **front-end only**. Demo customer and parcel records are stored in browser `localStorage`. It does not connect to Express.js or MySQL yet. To use a real database, build and connect the backend APIs later.

Tracking IDs in the front-end demo use the `TANUSH` prefix (for example, `TANUSH12345678`).
